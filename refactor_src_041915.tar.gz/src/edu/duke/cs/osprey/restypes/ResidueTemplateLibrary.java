/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.restypes;

import edu.duke.cs.osprey.control.EnvironmentVars;
import edu.duke.cs.osprey.structure.Atom;
import edu.duke.cs.osprey.structure.Residue;
import edu.duke.cs.osprey.tools.StringParsing;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 *
 * @author mhall44
 */
public class ResidueTemplateLibrary {
    //This library of residue templates defines what types of residues we can model
    //and what flexibility and energy parameters come with each type
    //NAMING: We assume each distinct residue (AA or otherwise) has its own name
    //however, many residues will have multiple slightly different forms (N-terminal, etc.) 
    //and these will share a name and a rotamer library entry
    
    //PUT ONE OF THESE IN ENVIRONMENTVARS
    
    public ArrayList<ResidueTemplate> templates;
    
    RotamerLibrary rl;
    
    public ResidueTemplateLibrary(String[] templateFiles){
        //create a library based on template files
        //we can then load coordinates and rotamer libraries for these templates separately, if we have these

        for(String fileName : templateFiles){
            loadTemplates(fileName);
        }
    }
        
        
    public void loadTemplates(String templateFile){//load templates from the indicated files,
        //and add them to our list of templates
        try {

            FileInputStream is = new FileInputStream( EnvironmentVars.getDataDir().concat(templateFile) );
            BufferedReader bufread = new BufferedReader(new InputStreamReader(is));
            String curLine = null, tmpName = null;
            int dumPresent = 0;
            numAAs = numAANTs = numAACTs = 0;
            aaResidues = new Residue[30];
            aaNTResidues = new Residue[30];
            aaCTResidues = new Residue[30];

            // Skip over first 2 lines of header info
            curLine = bufread.readLine();
            curLine = bufread.readLine();

            while( curLine != null ) {
                    // Skip over first line which is the long amino acid name
                    curLine = bufread.readLine();
                    if (curLine.length() >= 4)
                            if (curLine.substring(0,4).equalsIgnoreCase("stop")) {
                                    curLine = bufread.readLine();
                                    continue;
                            }
                    // Skip blank line
                    curLine = bufread.readLine();
                    // The next line contains the 3 letter amino acid name
                    curLine = bufread.readLine();
                    tmpName = StringParsing.getToken(curLine,1);
                    Residue newRes = new Residue();
                    newRes.name = tmpName;
                    // Skip next 2 lines
                    curLine = bufread.readLine();
                    curLine = bufread.readLine();
                    // Now we're into the section with atoms
                    curLine = bufread.readLine();
                    // Skip the dummy atoms
                    dumPresent = 0;
                    while (StringParsing.getToken(curLine,2).equalsIgnoreCase("DUMM")) {
                            dumPresent++;
                            curLine = bufread.readLine();
                    }
                    dumPresent++; // to adjust for 0-based
                    while (!StringParsing.getToken(curLine,2).equals("")) {
                            Atom at = new Atom();
                            tmpName = StringParsing.getToken(curLine,2);
                            at.changeType(tmpName);
                            at.forceFieldType = StringParsing.getToken(curLine,3);
                            at.charge = (double) (new Double(StringParsing.getToken(curLine,11)).doubleValue());
                            at.isBBatom = at.setIsBBatom();
                            //KER: The first atom is bonded to a dummy atom so we can't include that
                            //KER: in the bond list, so check atom is >= 0
                            int atomBondedTo = ((new Integer(StringParsing.getToken(curLine,5))).intValue())-dumPresent;
                            if(atomBondedTo >=0)
                                    at.addBond(atomBondedTo);
                            newRes.addAtom(at);  // add atom
                            curLine = bufread.readLine();  // read next line
                    }

                    //KER: Read LOOP data if any
                    curLine = bufread.readLine();
                    if (curLine.length() >= 4){
                            if(StringParsing.getToken(curLine, 1).equalsIgnoreCase("LOOP")){
                                    curLine = bufread.readLine();
                                    while(!StringParsing.getToken(curLine,2).equals("")){
                                            //find atom1
                                            for(Atom a : newRes.atom){
                                                    if(a.name.equalsIgnoreCase(StringParsing.getToken(curLine,1))){
                                                            //find atom2
                                                            for(Atom b : newRes.atom){
                                                                    if(b.name.equalsIgnoreCase(StringParsing.getToken(curLine,2))){
                                                                            a.addBond(b.residueAtomNumber);
                                                                    }
                                                            }
                                                    }
                                            }
                                            curLine = bufread.readLine();
                                    }
                            }
                    }

                    // Eventually we might want to be able to handle the improper
                    //  torsions listed here

                    // Add the residue to the array
                    aaResidues[numAAs++] = newRes;
                    // Read until the end of the residue
                    boolean atDone = false;
                    if (curLine.length() >= 4)
                            atDone = curLine.substring(0,4).equalsIgnoreCase("done");
                    else
                            atDone = false;
                    while (!atDone) {
                            curLine = bufread.readLine();
                            if (curLine.length() >= 4)
                                    atDone = curLine.substring(0,4).equalsIgnoreCase("done");
                            }
            }
            bufread.close();
        }
        catch (FileNotFoundException e) {
                System.out.println("ERROR: Template File Not Found: "+e);
                e.printStackTrace();
                System.exit(0);
        }
        catch (IOException e) {
                System.out.println("ERROR reading template file: "+e);
                e.printStackTrace();
                System.exit(0);
        }
    }
    
    
    public void loadTemplateCoords(String fileName){
        //load coordinates for templates, given in the following file
        //they should match templates that are already loaded (same residue and atom names)
        //we will need coordinates for any residue type that we mutate to
        
        try {
                
            FileInputStream is = new FileInputStream( EnvironmentVars.getDataDir().concat(aaFilename) );
            BufferedReader bufread = new BufferedReader(new InputStreamReader(is));
            String curLine = null, tmpName = null;
            int tmpCtr = 0;

            curLine = bufread.readLine();
            while ( curLine.startsWith("#") ){
                    curLine = bufread.readLine();
            }
            boolean foundRes = false;
            boolean foundAtom = false;
            while (curLine != null ){
                    String resName = StringParsing.getToken(curLine,1);
                    int numAtoms = new Integer(StringParsing.getToken(curLine,2)); 
                    foundRes = false;
                    for(int j = 0; j<numAAs; j++){
                            Residue r = aaResidues[j];
                            //the coord template matches the forcefield template
                            if(r.name.equalsIgnoreCase(resName)){
                                    foundRes = true;
                                    for(int i=0;i<numAtoms;i++){
                                            curLine = bufread.readLine();
                                            //Find the current atom in the residue
                                            foundAtom = false;
                                            for(Atom a:r.atom){
                                                    if(a.name.equalsIgnoreCase(StringParsing.getToken(curLine,1))){
                                                            foundAtom = true;
                                                            a.setCoords(new Double(StringParsing.getToken(curLine,2)), new Double(StringParsing.getToken(curLine,3)), new Double(StringParsing.getToken(curLine,4)));
                                                            break;
                                                    }
                                            }
                                            if(!foundAtom){
                                                    System.out.println("Residue coord and forcefield templates did not match up.");
                                                    System.exit(0);
                                            }		
                                    }
                                    break;
                            }
                    }
                    //If we didn't find a match we need to get rid of those 
                    //lines from the file
                    if(!foundRes){
                            for(int i=0; i<numAtoms;i++){
                                    curLine=bufread.readLine();
                            }
                    }
                    //Read to catch the ENDRES line and then
                    //get the start of the next AA
                    curLine = bufread.readLine();
                    curLine = bufread.readLine();
            }
            bufread.close();
        }
        catch (FileNotFoundException e) {
                System.out.println("ERROR: Template File Not Found: "+e);
                e.printStackTrace();
                System.exit(0);
        }
        catch (IOException e) {
                System.out.println("ERROR reading template file: "+e);
                e.printStackTrace();
                System.exit(0);
        }
        
    }
    
    
    public void loadRotamerLibrary(String fileName){
        rl = read();//Make RotamerLoader class?  Should load into the templates we have
    }
    
    
    
    //Functions to get templates and information from them
    
    public int numDihedralsForResType(String resType){
        //number of free dihedrals (sidechain dihedrals for actual amino acids)
        return firstTemplate(resType).numDihedrals;
    }
    
    public int numRotForResType(String resType){
        //number of rotamers
        return firstTemplate(resType).numRotamers;
        
    }
    
    public double getDihedralForRotamer(String resType, int rotNum, int dihedralNum){
        //get ideal dihedral value for a particular rotamer of a particular residue type
        //rotNum, dihedralNum both specific to resType
        return firstTemplate(resType).rotamericDihedrals[rotNum][dihedralNum];
    }
    
    
    public ResidueTemplate firstTemplate(String resType){
        //get the first template with the given residue type 
        //templates with the same type will all have the same rotamers, etc.
        //so this is good for looking up things like that
        for(ResidueTemplate templ : templates){
            if( templ.name.equalsIgnoreCase(resType) )
                return templ;
        }
        throw new RuntimeException("ERROR: template not found for residue type "+resType);
    }
    
    
    public ResidueTemplate getTemplateForMutation(String resTypeName, Residue res){
        //We want to mutate res to type resTypeName.  Get the appropriate template.
        for(ResidueTemplate template : templates){
            if(template.name.equalsIgnoreCase(resTypeName)){
                
            }
        }
    }
    
    
    
}

