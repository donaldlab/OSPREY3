/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.restypes;

import edu.duke.cs.osprey.structure.Atom;
import edu.duke.cs.osprey.structure.Residue;
import java.util.ArrayList;

/**
 *
 * @author mhall44
 */
public class ResidueTemplate {
    //This class defines a residue type, like ARG or H2O or whatever
    //structures are composed entirely of residues. 
    //We need to identify the type of each residue whenever we want to move it it a residue-specific way
    //(e.g. to define sidechain dihedrals and rotamers),
    //or whenever we want to evaluate its energy (except by an ab initio method that takes only element 
    //types and coordinates)
    //We will also need these templates to mutate from one type to another
    
    //any of the information below can be null (i.e., not provided), but if so 
    //then attempts to call it will produce an error
    
    
    public String name;//e.g. ARG
    
    //"standard" residue
    //info from here will mostly be copied into any residue in the structure to which this template is assigned
    //(charges, standardized atom names, bonds, etc.)
    public Residue templateRes;
    
    //dihedral information
    public int numDihedrals;
    public int dihedral4Atoms[][];//for each dihedral, list of 4 atoms defining it
    //these are indices in all our atom-wise arrays
    public int dihedralMovingAtoms[][];//list of atoms that move for each dihedral
    
    
    //rotamer information
    public int numRotamers;
    
    //note: this is just the standard set of ideal rotamers, we can modify this as desired
    
    
    //information on dihedrals
    public int[] getDihedralDefiningAtoms(int dihedralNum){
        //numbers (indices among the atoms in this template) of the 4 atoms defining the dihedral
        return dihedral4Atoms[dihedralNum];
    }
    
    public int[] getDihedralRotatedAtoms(int dihedralNum){
        //the atoms that actually move (including the 4th of the dihedral-defining atoms)
        return dihedralMovingAtoms[dihedralNum];
    }
    
    
    public int[][] findMutAlignmentAtoms(ResidueTemplate template2){
        /*List indices of atoms in this residue (ans[0]) and the other
         * (ans[1]) that can be aligned to perform a mutation
         * Starting off with the standard protein ones (L- or D-supported),
         * add more later
         */
        
        //look for standard BB atoms: N, CA, C, and CB (HA2 instead of CB for Gly)
        //complain if can't find them
        int N1 = templateRes.getAtomIndexByName("N");
        int CA1 = templateRes.getAtomIndexByName("CA");
        int C1 = templateRes.getAtomIndexByName("C");
        
        int CB1 = templateRes.getAtomIndexByName("CB");
        if(name.equalsIgnoreCase("GLY"))
            CB1 = templateRes.getAtomIndexByName("HA2");
        
        int mutAtoms1[] = new int[] {CA1,N1,C1,CB1};//indices of atoms to align from first residue
            
        
        int N2 = templateRes.getAtomIndexByName("N");
        int CA2 = templateRes.getAtomIndexByName("CA");
        int C2 = templateRes.getAtomIndexByName("C");
        
        int CB2 = templateRes.getAtomIndexByName("CB");
        if(name.equalsIgnoreCase("GLY"))
            CB2 = templateRes.getAtomIndexByName("HA2");
        
        int mutAtoms2[] = new int[] {CA2,N2,C2,CB2};
        
        
        for( int atNum : new int[] {N1,CA1,C1,CB1,N2,CA2,C2,CB2} ){
            if(atNum==-1){//some atom(s) not found
                throw new UnsupportedOperationException("ERROR: Mutation from "
                        +name+" to "+template2.name+" not supported yet");
            }
        }
        
        return new int[][] {mutAtoms1,mutAtoms2};
    }
    
    
}
