/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.structure;

import java.util.ArrayList;

/**
 *
 * @author mhall44
 */
public class Atom {
    //this atom is part of a residue.  It can be assigned a forcefield type but doesn't have to be.
    //coordinates are stored by the residue, not here
    
    public Residue res;//what residue is it in?
    public int indexInRes;//what is the index of this atom in the residue?
    
    //These can be gotten from the PDB file
    public String name;//like CA or whatever
    public String elementType;//like C or whatever
    public double BFactor=0;//optional...leave all at 0 if not provided
    public int modelAtomNumber=-1;//number in PDB file
    
    
    //OPTIONAL (get from ResTemplate if appropriate)
    public String forceFieldType;
    public int type;//integer version
    public double charge;
    public Atom bonds[];//what atoms is it bonded to?

    

    
    
    public Atom(String name, String elementType, double BFactor, int modelAtomNumber) {
        this.name = name;
        this.elementType = elementType;
        this.BFactor = BFactor;
        this.modelAtomNumber = modelAtomNumber;
    }
    
    public Atom(String name, String elementType) {
        this.name = name;
        this.elementType = elementType;
    }
    
    
    
    public Atom copy(){
        //copy the atom, leaving the residue and bonds blank
        //(since these will need to be pointed to the right objects)
        Atom ans = new Atom(name,elementType,BFactor,modelAtomNumber);
        
        ans.indexInRes = indexInRes;
        //this is useful because we'll usually be copying from the template
        
        ans.res = null;
        ans.bonds = null;
        
        ans.charge = charge;
        ans.type = type;
        ans.forceFieldType = forceFieldType;
        
        return ans;
    }
    
    

}
