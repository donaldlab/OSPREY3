/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.structure;

import edu.duke.cs.osprey.control.EnvironmentVars;
import edu.duke.cs.osprey.restypes.ResTemplateMatching;
import edu.duke.cs.osprey.restypes.ResidueTemplate;
import edu.duke.cs.osprey.restypes.ResidueTemplateLibrary;
import edu.duke.cs.osprey.tools.StringParsing;
import java.util.ArrayList;

/**
 *
 * @author mhall44
 */
public class Residue {
    //This is a residue
    //in the general sense: it's a piece of a molecular system that can mutate, take on RCs, etc.
    //and is the basic unit for energy calculations: energy is broken down to intra-residue energies,
    //pairwise interactions between residues, and maybe a few triples etc.
    
    //residue information
    public String fullName;//short name is the first three characters of this
    
    int indexInMolecule = -1;//index of this residue in the molecule it's in
    public ResidueTemplate template = null;
    //this gives the name of the residue like "GLU" or "H2O" or whatever
    //and any information about bonds, force-field, rotatable dihedrals, and rotamers
    //ONLY ASSIGN USING ASSIGNTEMPLATE (will reorder atoms to match template)
    
    
    //Residue[] neighbors;//The ResidueTemplate specifies a certain number of residues that should be bonded to this one
    //usually two, through backbone bonds, but there could be exceptions (disulfides, unbonded ligands without neighbors,
    //weird non-protein stuff)
    //if neighbors[i] is null that means the i'th neighbor is missing from the structure
    
    //atom information
    public ArrayList<Atom> atoms;//information on individual atoms
    //(when assigning the template we will copy this from the template)
    
    
    public double coords[];//coordinates of all the atoms: x1, y1, z1, x2, ...
    //we want the coordinates to be all in one place and fairly cache-friendy
    //(e.g. when doing pairwise minimizations, polynomial fits, etc. we can easily cache these coordinates
    //for our residues of interest and access them quickly)
    
    public Residue(ArrayList<Atom> atomList, ArrayList<double[]> coordList, String nameFull){
        //generate a residue.  Don't put in template and related stuff like bonds (that can be assigned later)
        
        atoms = atomList;
        
        int numAtoms = atoms.size();
        if(numAtoms != coordList.size()){
            throw new RuntimeException("ERROR: Trying to instantiate residue with "+numAtoms+
                    " atoms but "+coordList.size()+" atom coordinates");
        }
        
        coords = new double[3*numAtoms];
        for(int a=0; a<numAtoms; a++){
            System.arraycopy(coordList.get(a), 0, coords, 3*a, 3);
            atoms.get(a).res = this;
            atoms.get(a).indexInRes = a;
        }
        
        fullName = nameFull;
    }
    
    public String getPDBResNumber() {
            if (fullName.length() > 5)
                    return( (StringParsing.getToken(fullName.substring(5),1)) );
            return Integer.toString(indexInMolecule+1);
    }
    
    boolean assignTemplate (){
        //assign a template to this residue if possible, using the ResidueTemplateLibrary
        //return if successful or not
        
        //we'll use the default ResidueTemplateLibrary (from EnvironmentVars)
        ResidueTemplateLibrary templateLib = EnvironmentVars.resTemplates;
        
        //first see if there are any templates matching this name
        ArrayList<ResidueTemplate> templCandidates = new ArrayList<>();
        String resName = fullName.substring(0,3);
        for(ResidueTemplate templ : templateLib.templates){
            if(templ.name.equalsIgnoreCase(resName))//OR ALT NAME OF TEMPLATE??
                templCandidates.add(templ);
        }
        
        if(templCandidates.isEmpty())
            return false;
        
        
        //now try to match up atoms
        ResTemplateMatching bestMatching = null;
        double bestScore = Double.POSITIVE_INFINITY;
        
        for(ResidueTemplate templ : templCandidates){
            ResTemplateMatching templMatching = new ResTemplateMatching(this,templ);
            if(templMatching.score < bestScore){
                bestScore = templMatching.score;
                bestMatching = templMatching;
            }
        }
        
        if(bestMatching==null)//no good matching found
            return false;
        
        //now rename/order atoms in this residue to match template!
        bestMatching.assign();
        return true;//matched successfully!
    }
    
    
    
    public void findBondsByTemplate(){
        //assign bonds to all atoms, based on the template
        
        
        //check that all atoms have the same names as
        //corresponding template atoms, in the same order
        
        
        //Within-residue bonds are exactly as in the template
        boolean[] intraResBondMatrix = template.templateRes.intraResBondMatrix();
        for(int atNum=0; atNum<atoms.size(); atNum++){
            //apply matrix
        }
        
        
        //and we 
        using the template to determine within-residu;
        
        
        //Between-residue bonds are based on a function in the library
        foreach null bond:
            templatelib.getBondedAtom(atom.name);//find other atom (e.g. prev res C)
        
        //check here that all bonds have been made
    }
    
    
    public int getAtomIndexByName(String n){
        
        for(int atNum=0; atNum<atoms.size(); atNum++){
            if(atoms.get(atNum).name.equalsIgnoreCase(n))
                return atNum;
        }
        
        return -1;
    }
    
    
    public double distanceTo(Residue res2){
        //distance between the residues (measured at the closest atoms)
        double minDist2 = Double.POSITIVE_INFINITY;//minimum squared distance
        
        //for both residues, coordinates are concatenated 3-vectors
        for(int atNum1=0; atNum1<atoms.size(); atNum1++){
            for(int atNum2=0; atNum2<res2.atoms.size(); atNum2++){
                
                double dx = coords[3*atNum1] - res2.coords[3*atNum2];//difference in x coordinates between the two atoms
                double dy = coords[3*atNum1+1] - res2.coords[3*atNum2+1];
                double dz = coords[3*atNum1+2] - res2.coords[3*atNum2+2];
                double dist2 = dx*dx + dy*dy + dz*dz;//squared distance between atoms
                
                minDist2 = Math.min(minDist2,dist2);
            }
        }
        
        return Math.sqrt(minDist2);
    }
    
    
    
    
    public double[][] atomDistanceMatrix(){
        //matrix of distances between all atoms
        int numAtoms = atoms.size();
        double[][] ans = new double[numAtoms][numAtoms];
        
        for(int atNum1=0; atNum1<numAtoms; atNum1++){
            for(int atNum2=0; atNum2<numAtoms; atNum2++){
                
                double dx = coords[3*atNum1] - coords[3*atNum2];//difference in x coordinates between the two atoms
                double dy = coords[3*atNum1+1] - coords[3*atNum2+1];
                double dz = coords[3*atNum1+2] - coords[3*atNum2+2];
                double dist = Math.sqrt( dx*dx + dy*dy + dz*dz );
                
                ans[atNum1][atNum2] = dist;
            }
        }
        
        return ans;
    }
    
}
