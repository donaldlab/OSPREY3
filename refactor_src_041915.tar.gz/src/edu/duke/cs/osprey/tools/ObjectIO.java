/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.tools;

/**
 *
 * @author mhall44
 */

//tools for storing objects, like an energy matrix

public class ObjectIO {
    
    public static Object readObject( String fileName, boolean allowNull ){
        //Read the object from the file
        //If cannot (e.g., because object doesn't exist), then return null if allowNull, else 
        //raise an error
        
    }
    
    public static void writeObject( Object obj, String fileName ){
        from(KSParser);
    }
    
}
