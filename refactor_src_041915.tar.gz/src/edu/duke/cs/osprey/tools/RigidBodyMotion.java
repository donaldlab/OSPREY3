/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.tools;

/**
 *
 * @author mhall44
 */
public class RigidBodyMotion {
    //can include a rotation and/or a translation
    
    
    
    public static RigidBodyMotion superimposingMotion(double[][] initCoords, double[][] finalCoords){
        //return the rigid-body motion that best maps the 3-D vectors in initCoords to those in finalCoords
        //(in a least-squares sense)
    }
    
    public void transform(double[] concatCoords){
        //given a bunch of concatenated 3D vectors, apply the transformation to each of them, in place
        transform;
    }
    
}
