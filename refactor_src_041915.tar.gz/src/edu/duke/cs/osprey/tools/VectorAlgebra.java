/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.tools;

/**
 *
 * @author mhall44
 */
public class VectorAlgebra {
    
    public static double[] subtract(double[] x, double[] y){
        
    }
}
