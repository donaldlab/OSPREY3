/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.tools;

/**
 *
 * @author mhall44
 */
public class Protractor {
    //Measure angles
    
    
    public static double measureDihedral(double[][] coords){
        //given 3D coords for four atoms, return their dihedral (standard sign convention)
    }
    
}
