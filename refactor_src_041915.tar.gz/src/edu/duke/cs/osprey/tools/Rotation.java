/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.duke.cs.osprey.tools;

import cern.colt.matrix.DoubleFactory1D;

/**
 *
 * @author mhall44
 */
public class Rotation {
    
    double[] center;
    DoubleMatrix2D rotMatrix;//rotate about center using rotation matrix rotMatrix
    
    
    public Rotation(double[] center, double[] axis, double angle){
        //build rotation from center, axis, and angle
        this.center = center;
        
        rotMatrix = makeRotMatrix(axis,angle);
    }
    
    public void applyRotation(double[] x, int index){
        //Given the concatenated 3-D coordinates of a bunch of atoms,
        //apply rotation to the atom with the given index
        DoubleFactory1D.dense.make(x).viewPart(3*index,3).rotate;
    }
}
